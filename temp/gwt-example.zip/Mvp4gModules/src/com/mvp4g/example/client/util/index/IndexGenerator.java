package com.mvp4g.example.client.util.index;

public interface IndexGenerator {
	
	public int generateIndex(int  baseIndex);

}
