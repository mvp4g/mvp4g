package com.mvp4g.example.client.util;

public interface HasBeenThereHandler {

}
