package com.mvp4g.example.client.util.index;

public class SameIndexGenerator implements IndexGenerator {

	public int generateIndex( int baseIndex ) {
		return baseIndex;
	}

}
