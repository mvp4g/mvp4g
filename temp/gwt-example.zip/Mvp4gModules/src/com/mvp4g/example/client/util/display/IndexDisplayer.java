package com.mvp4g.example.client.util.display;

public interface IndexDisplayer {
	
	public String getDisplay(int value);

}
