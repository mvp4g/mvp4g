package com.mvp4g.example.client.presenter.interfaces;

import com.google.gwt.user.client.ui.IsWidget;
import com.mvp4g.client.view.LazyView;

public interface IPage2View extends IsWidget, LazyView {

	public interface IPage2Presenter {

	}
	
	void setName(String name);

}
