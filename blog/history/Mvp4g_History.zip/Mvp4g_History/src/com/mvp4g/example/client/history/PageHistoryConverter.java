package com.mvp4g.example.client.history;

import com.mvp4g.client.annotation.History;
import com.mvp4g.client.annotation.History.HistoryConverterType;
import com.mvp4g.client.history.HistoryConverter;
import com.mvp4g.example.client.HistoryEventBus;

@History( type = HistoryConverterType.SIMPLE )
public class PageHistoryConverter implements HistoryConverter<HistoryEventBus> {

	public String convertToToken( String eventName, String name ) {
		return name;
	}

	@Override
	public void convertFromToken( String name, String param, HistoryEventBus eventBus ) {
		eventBus.dispatch( name, param );
	}

	@Override
	public boolean isCrawlable() {
		return false;
	}

}
