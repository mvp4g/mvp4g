package com.mvp4g.example.client.presenter;

import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.LazyPresenter;
import com.mvp4g.example.client.HistoryEventBus;
import com.mvp4g.example.client.presenter.interfaces.IPage1View;
import com.mvp4g.example.client.presenter.interfaces.IPage1View.IPage1Presenter;
import com.mvp4g.example.client.view.Page1View;

@Presenter(view = Page1View.class)
public class Page1Presenter extends LazyPresenter<IPage1View, HistoryEventBus> implements IPage1Presenter {

	public void onGoToPage1(String name){
		view.setName( name );
		eventBus.setBody( view );
	}
	
}
