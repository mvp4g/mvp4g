package com.mvp4g.example.client.presenter.interfaces;

import com.google.gwt.user.client.ui.IsWidget;

//for this example, our footer is so simple, it does nothing ;)
//I created a footer just to illustrate how layout works
public interface IFooterView extends IsWidget {

	public interface IFooterPresenter {

	}

}
