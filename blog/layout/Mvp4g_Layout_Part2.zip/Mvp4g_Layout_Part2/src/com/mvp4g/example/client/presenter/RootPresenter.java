package com.mvp4g.example.client.presenter;

import com.google.gwt.user.client.ui.IsWidget;
import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.BasePresenter;
import com.mvp4g.example.client.LayoutExampleEventBus;
import com.mvp4g.example.client.presenter.interfaces.IRootView;
import com.mvp4g.example.client.presenter.interfaces.IRootView.IRootPresenter;
import com.mvp4g.example.client.view.RootView;

@Presenter( view = RootView.class )
public class RootPresenter extends BasePresenter<IRootView, LayoutExampleEventBus> implements IRootPresenter {

	public void onSetBody( IsWidget body ) {
		view.setBody( body );
	}

	public void onStart() {
		eventBus.goToPage1( "The application started." );
	}

}
