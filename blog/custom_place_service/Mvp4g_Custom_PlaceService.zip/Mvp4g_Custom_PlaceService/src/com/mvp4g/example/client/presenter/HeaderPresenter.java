package com.mvp4g.example.client.presenter;

import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.BasePresenter;
import com.mvp4g.example.client.CustomPlaceServiceEventBus;
import com.mvp4g.example.client.presenter.interfaces.IHeaderView;
import com.mvp4g.example.client.presenter.interfaces.IHeaderView.IHeaderPresenter;
import com.mvp4g.example.client.view.HeaderView;

@Presenter(view = HeaderView.class)
public class HeaderPresenter extends BasePresenter<IHeaderView, CustomPlaceServiceEventBus> implements IHeaderPresenter {
	
	public void onStart(){
		//nothing to do
	}
	
}
