package com.mvp4g.example.client.presenter.interfaces;

import com.google.gwt.user.client.ui.HasValue;
import com.google.gwt.user.client.ui.IsWidget;
import com.mvp4g.client.view.LazyView;

public interface ILoginView extends IsWidget, LazyView {

	public interface ILoginPresenter {

		void onLoginClick();

	}

	HasValue<String> getUsername();

	HasValue<String> getPassword();

}
