package com.mvp4g.example.client.view;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Singleton;
import com.mvp4g.example.client.presenter.interfaces.IHeaderView;
import com.mvp4g.example.client.presenter.interfaces.IHeaderView.IHeaderPresenter;

@Singleton
public class HeaderView extends ReverseCompositeView<IHeaderPresenter> implements IHeaderView {

	private static HeaderViewUiBinder uiBinder = GWT.create( HeaderViewUiBinder.class );

	interface HeaderViewUiBinder extends UiBinder<Widget, HeaderView> {
	}

	@UiField
	Anchor logout;

	public HeaderView() {
		initWidget( uiBinder.createAndBindUi( this ) );
	}

	@Override
	public void setLogoutVisible( boolean visible ) {
		logout.setVisible( visible );
	}

	@UiHandler( "logout" )
	public void onLogoutClick( ClickEvent event ) {
		presenter.onLogoutClick();
	}

}
