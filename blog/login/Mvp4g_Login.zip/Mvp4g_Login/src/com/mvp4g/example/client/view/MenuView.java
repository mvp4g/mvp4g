package com.mvp4g.example.client.view;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Hyperlink;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Singleton;
import com.mvp4g.example.client.presenter.interfaces.IMenuView;
import com.mvp4g.example.client.presenter.interfaces.IMenuView.IMenuPresenter;

@Singleton
public class MenuView extends ReverseCompositeView<IMenuPresenter> implements IMenuView {

	private static MenuViewUiBinder uiBinder = GWT.create( MenuViewUiBinder.class );

	@UiField
	Hyperlink page1, page2;

	interface MenuViewUiBinder extends UiBinder<Widget, MenuView> {
	}

	public MenuView() {
		initWidget( uiBinder.createAndBindUi( this ) );
	}

	@Override
	public void setPage1Token( String token ) {
		page1.setTargetHistoryToken( token );
	}

	@Override
	public void setPage2Token( String token ) {
		page2.setTargetHistoryToken( token );
	}

}
