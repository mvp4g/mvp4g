package com.mvp4g.example.client;

import com.google.inject.Inject;
import com.mvp4g.client.event.EventFilter;

public class LoggedinFilter implements EventFilter<LoginEventBus> {

	@Inject
	Session session;

	@Override
	public boolean filterEvent( String eventName, Object[] params, LoginEventBus eventBus ) {
		boolean pass = session.isLoggedIn();
		if ( !pass ) {
			eventBus.setFilteringEnabled( false );
			eventBus.login();
			eventBus.setFilteringEnabled( true );
		}
		return pass;
	}

}
