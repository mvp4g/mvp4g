package com.mvp4g.example.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath( "sessionService" )
public interface SessionService extends RemoteService {

	String retrieveSession();

	void login( String username, String password );

	void logout();

}
