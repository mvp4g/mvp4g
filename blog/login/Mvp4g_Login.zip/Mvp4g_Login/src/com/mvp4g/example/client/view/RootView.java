package com.mvp4g.example.client.view;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.IsWidget;
import com.google.gwt.user.client.ui.SimplePanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.mvp4g.example.client.presenter.interfaces.IRootView;
import com.mvp4g.example.client.presenter.interfaces.IRootView.IRootPresenter;

public class RootView extends ReverseCompositeView<IRootPresenter> implements IRootView {

	private static RootViewUiBinder uiBinder = GWT.create( RootViewUiBinder.class );

	@UiField( provided = true )
	Widget header, footer, menu;

	@UiField
	SimplePanel body;

	interface RootViewUiBinder extends UiBinder<Widget, RootView> {
	}

	@Inject
	public RootView( HeaderView header, FooterView footer, MenuView menu ) {
		this.header = header;
		this.footer = footer;
		this.menu = menu;
		initWidget( uiBinder.createAndBindUi( this ) );
	}

	@Override
	public void setBody( IsWidget body ) {
		this.body.setWidget( body );
	}

}
