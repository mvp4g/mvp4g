package com.mvp4g.example.client.presenter.interfaces;

import com.google.gwt.user.client.ui.IsWidget;

public interface IMenuView extends IsWidget {

	public interface IMenuPresenter {

	}

	void setPage1Token( String token );

	void setPage2Token( String token );

}
