package com.mvp4g.example.client.presenter.interfaces;

import com.google.gwt.user.client.ui.IsWidget;
import com.mvp4g.client.view.LazyView;

public interface IPage1View extends IsWidget, LazyView {

	public interface IPage1Presenter {

	}

	void setOrigin( String name, String origin );

}
