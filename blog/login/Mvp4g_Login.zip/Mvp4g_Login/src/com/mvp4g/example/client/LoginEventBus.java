package com.mvp4g.example.client;

import com.google.gwt.user.client.ui.IsWidget;
import com.mvp4g.client.annotation.Event;
import com.mvp4g.client.annotation.Events;
import com.mvp4g.client.annotation.Filters;
import com.mvp4g.client.annotation.InitHistory;
import com.mvp4g.client.annotation.PlaceService;
import com.mvp4g.client.annotation.Start;
import com.mvp4g.client.event.EventBusWithLookup;
import com.mvp4g.example.client.history.PageHistoryConverter;
import com.mvp4g.example.client.presenter.FooterPresenter;
import com.mvp4g.example.client.presenter.HeaderPresenter;
import com.mvp4g.example.client.presenter.LoginPresenter;
import com.mvp4g.example.client.presenter.MenuPresenter;
import com.mvp4g.example.client.presenter.Page1Presenter;
import com.mvp4g.example.client.presenter.Page2Presenter;
import com.mvp4g.example.client.presenter.RootPresenter;

@PlaceService( CustomPlaceService.class )
@Events( startPresenter = RootPresenter.class, historyOnStart = true )
@Filters( filterClasses = LoggedinFilter.class, filterStart = false, afterHistory = true )
public interface LoginEventBus extends EventBusWithLookup {

	@Start
	@Event( bind = { FooterPresenter.class, HeaderPresenter.class, MenuPresenter.class } )
	void start();

	@InitHistory
	@Event( handlers = RootPresenter.class )
	void init();

	/*
	 * Layout events
	 */
	@Event( handlers = RootPresenter.class )
	void setBody( IsWidget body );

	/*
	 * Place events
	 */
	@Event( handlers = Page1Presenter.class, historyConverter = PageHistoryConverter.class, name = "page1", navigationEvent = true )
	String goToPage1( String origin );

	@Event( handlers = Page2Presenter.class, historyConverter = PageHistoryConverter.class, name = "page2", navigationEvent = true )
	String goToPage2( String origin );

	@Event( handlers = LoginPresenter.class )
	void login();

	@Event( handlers = HeaderPresenter.class, passive = true )
	void sessionChanged();

}
