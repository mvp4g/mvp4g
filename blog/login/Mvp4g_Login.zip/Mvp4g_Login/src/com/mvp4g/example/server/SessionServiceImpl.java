package com.mvp4g.example.server;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.mvp4g.example.client.SessionService;

public class SessionServiceImpl extends RemoteServiceServlet implements SessionService {

	private static final long serialVersionUID = 1L;

	private static final String USERNAME = "username";

	@Override
	public String retrieveSession() {
		return (String)getThreadLocalRequest().getSession().getAttribute( USERNAME );
	}

	@Override
	public void login( String username, String password ) {
		getThreadLocalRequest().getSession().setAttribute( USERNAME, username );
	}

	@Override
	public void logout() {
		getThreadLocalRequest().getSession().removeAttribute( USERNAME );
	}

}
