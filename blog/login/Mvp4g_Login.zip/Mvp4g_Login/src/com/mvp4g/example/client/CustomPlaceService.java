package com.mvp4g.example.client;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.mvp4g.client.Mvp4gModule;
import com.mvp4g.client.history.PlaceService;

public class CustomPlaceService extends PlaceService {

	@Inject
	Session session;

	@Inject
	SessionServiceAsync sessionService;

	private LoginEventBus eventBus;

	@Override
	public void setModule( Mvp4gModule module ) {
		super.setModule( module );
		eventBus = (LoginEventBus)module.getEventBus();
	}

	@Override
	public String tokenize( String eventName, String param ) {
		//always add the paramSeparator since "/" is used for module separator and paramSeparator
		String token = eventName + getParamSeparator();
		if ( ( param != null ) && ( param.length() > 0 ) ) {
			token = token + param;
		}
		return token;
	}

	protected String getParamSeparator() {
		return "/";
	}

	protected void convertToken( final String token ) {
		sessionService.retrieveSession( new AsyncCallback<String>() {

			@Override
			public void onSuccess( String result ) {
				updateSession( result, token );
			}

			@Override
			public void onFailure( Throwable caught ) {
				updateSession( null, token );
			}
		} );
	}

	private void updateSession( String username, String token ) {
		session.setUsername( username );
		// Don't filter this event.
		eventBus.setFilteringEnabledForNextOne( false );
		eventBus.sessionChanged();
		CustomPlaceService.super.convertToken( token );
	}

}
