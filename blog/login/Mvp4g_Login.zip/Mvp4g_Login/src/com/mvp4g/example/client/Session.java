package com.mvp4g.example.client;

import com.google.inject.Singleton;

@Singleton
public class Session {

	private String username;

	public String getUsername() {
		return username;
	}

	public void setUsername( String username ) {
		this.username = username;
	}

	public boolean isLoggedIn() {
		return ( username != null ) && ( username.length() > 0 );
	}

}
