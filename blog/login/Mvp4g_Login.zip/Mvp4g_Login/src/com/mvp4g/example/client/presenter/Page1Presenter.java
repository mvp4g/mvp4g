package com.mvp4g.example.client.presenter;

import com.google.inject.Inject;
import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.LazyPresenter;
import com.mvp4g.example.client.LoginEventBus;
import com.mvp4g.example.client.Session;
import com.mvp4g.example.client.presenter.interfaces.IPage1View;
import com.mvp4g.example.client.presenter.interfaces.IPage1View.IPage1Presenter;
import com.mvp4g.example.client.view.Page1View;

@Presenter( view = Page1View.class )
public class Page1Presenter extends LazyPresenter<IPage1View, LoginEventBus> implements IPage1Presenter {

	@Inject
	Session session;

	public void onGoToPage1( String origin ) {
		view.setOrigin( session.getUsername(), origin );
		eventBus.setBody( view );
	}

}
