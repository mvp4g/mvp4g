package com.mvp4g.example.client.view;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.HasValue;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;
import com.mvp4g.example.client.presenter.interfaces.ILoginView;
import com.mvp4g.example.client.presenter.interfaces.ILoginView.ILoginPresenter;

public class LoginView extends ReverseCompositeView<ILoginPresenter> implements ILoginView {

	private static LoginViewUiBinder uiBinder = GWT.create( LoginViewUiBinder.class );

	interface LoginViewUiBinder extends UiBinder<Widget, LoginView> {
	}

	@UiField
	TextBox username, password;

	@UiHandler( "login" )
	public void onSaveClick( ClickEvent event ) {
		presenter.onLoginClick();
	}

	@Override
	public void createView() {
		//don't create the view before to take advantage of the lazy loading mechanism
		initWidget( uiBinder.createAndBindUi( this ) );
	}

	@Override
	public HasValue<String> getUsername() {
		return username;
	}

	@Override
	public HasValue<String> getPassword() {
		return password;
	}

}
