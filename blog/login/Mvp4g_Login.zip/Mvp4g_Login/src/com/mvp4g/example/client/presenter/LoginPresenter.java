package com.mvp4g.example.client.presenter;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.LazyPresenter;
import com.mvp4g.example.client.LoginEventBus;
import com.mvp4g.example.client.SessionServiceAsync;
import com.mvp4g.example.client.presenter.interfaces.ILoginView;
import com.mvp4g.example.client.presenter.interfaces.ILoginView.ILoginPresenter;
import com.mvp4g.example.client.view.LoginView;

@Presenter( view = LoginView.class )
public class LoginPresenter extends LazyPresenter<ILoginView, LoginEventBus> implements ILoginPresenter {

	@Inject
	private SessionServiceAsync sessionService;

	@Override
	public void onLoginClick() {
		String username = view.getUsername().getValue();
		String password = view.getPassword().getValue();
		sessionService.login( username, password, new AsyncCallback<Void>() {

			@Override
			public void onSuccess( Void result ) {
				// Refresh the application with the new session state.
				eventBus.getHistory().fireCurrentHistoryState();
			}

			@Override
			public void onFailure( Throwable caught ) {
				// Treat error.				
			}
		} );
	}

	public void onLogin() {
		view.getUsername().setValue( "" );
		view.getPassword().setValue( "" );
		eventBus.setBody( view );
	}

}
