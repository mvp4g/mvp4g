package com.mvp4g.example.client.presenter;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.BasePresenter;
import com.mvp4g.example.client.LoginEventBus;
import com.mvp4g.example.client.Session;
import com.mvp4g.example.client.SessionServiceAsync;
import com.mvp4g.example.client.presenter.interfaces.IHeaderView;
import com.mvp4g.example.client.presenter.interfaces.IHeaderView.IHeaderPresenter;
import com.mvp4g.example.client.view.HeaderView;

@Presenter( view = HeaderView.class )
public class HeaderPresenter extends BasePresenter<IHeaderView, LoginEventBus> implements IHeaderPresenter {

	@Inject
	Session session;

	@Inject
	SessionServiceAsync sessionService;

	@Override
	public void bind() {
		super.bind();
		// Display the logout button if needed.
		onSessionChanged();
	}

	@Override
	public void onLogoutClick() {
		// Logout the user.
		sessionService.logout( new AsyncCallback<Void>() {

			@Override
			public void onSuccess( Void result ) {
				// Refresh the application with the new session state.
				eventBus.getHistory().fireCurrentHistoryState();
			}

			@Override
			public void onFailure( Throwable caught ) {
				// Treat error.
			}
		} );
	}

	public void onSessionChanged() {
		view.setLogoutVisible( session.isLoggedIn() );
	}

}
