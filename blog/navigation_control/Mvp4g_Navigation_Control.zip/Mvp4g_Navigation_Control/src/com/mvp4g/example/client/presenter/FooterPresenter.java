package com.mvp4g.example.client.presenter;

import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.BasePresenter;
import com.mvp4g.example.client.NavigationControlEventBus;
import com.mvp4g.example.client.presenter.interfaces.IFooterView;
import com.mvp4g.example.client.presenter.interfaces.IFooterView.IFooterPresenter;
import com.mvp4g.example.client.view.FooterView;

@Presenter( view = FooterView.class )
public class FooterPresenter extends BasePresenter<IFooterView, NavigationControlEventBus> implements IFooterPresenter {

}
