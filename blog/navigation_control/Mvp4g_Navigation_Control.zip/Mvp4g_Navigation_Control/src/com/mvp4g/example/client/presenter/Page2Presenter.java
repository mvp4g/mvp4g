package com.mvp4g.example.client.presenter;

import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.history.NavigationConfirmationInterface;
import com.mvp4g.client.history.NavigationEventCommand;
import com.mvp4g.client.presenter.LazyPresenter;
import com.mvp4g.example.client.NavigationControlEventBus;
import com.mvp4g.example.client.bean.UserBean;
import com.mvp4g.example.client.presenter.interfaces.IPage2View;
import com.mvp4g.example.client.presenter.interfaces.IPage2View.IPage2Presenter;
import com.mvp4g.example.client.view.Page2View;

@Presenter( view = Page2View.class )
public class Page2Presenter extends LazyPresenter<IPage2View, NavigationControlEventBus> implements IPage2Presenter, NavigationConfirmationInterface {

	private UserBean user;

	@Override
	public void bindView() {
		user = new UserBean();
		user.setFirstName( "John" );
		user.setLastName( "Smith" );
	}

	public void onGoToPage2( String origin ) {
		//set the presenter to control the navigation when its view is being displayed
		eventBus.setNavigationConfirmation( this );

		view.setOrigin( origin );

		view.getFirstName().setValue( user.getFirstName() );
		view.getLastName().setValue( user.getLastName() );

		eventBus.setBody( view );
	}

	@Override
	public void onSaveClick() {
		user.setFirstName( view.getFirstName().getValue() );
		user.setLastName( view.getLastName().getValue() );
		view.alert( "User Info saved." );
	}

	@Override
	public void confirm( NavigationEventCommand event ) {
		boolean sameData = user.getFirstName().equals( view.getFirstName().getValue() ) && user.getLastName().equals( view.getLastName().getValue() );
		if ( sameData || view.confirm( "Data not saved, are you sure you want to leave the page?" ) ) {
			event.fireEvent();
		}
	}

}
