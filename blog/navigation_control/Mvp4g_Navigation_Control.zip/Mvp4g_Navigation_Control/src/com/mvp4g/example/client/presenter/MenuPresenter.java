package com.mvp4g.example.client.presenter;

import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.BasePresenter;
import com.mvp4g.example.client.NavigationControlEventBus;
import com.mvp4g.example.client.presenter.interfaces.IMenuView;
import com.mvp4g.example.client.presenter.interfaces.IMenuView.IMenuPresenter;
import com.mvp4g.example.client.view.MenuView;

@Presenter( view = MenuView.class )
public class MenuPresenter extends BasePresenter<IMenuView, NavigationControlEventBus> implements IMenuPresenter {

	public void onStart(){
		//nothing to do
	}

	@Override
	public void goToPage1() {
		eventBus.goToPage1( "You clicked the menu." );
	}

	@Override
	public void goToPage2() {
		eventBus.goToPage2( "You clicked the menu." );
	}

}
