package com.mvp4g.example.client.history;

import com.mvp4g.client.annotation.History;
import com.mvp4g.client.annotation.History.HistoryConverterType;
import com.mvp4g.client.history.HistoryConverter;
import com.mvp4g.example.client.HyperlinkNavigationEventBus;

@History( type = HistoryConverterType.SIMPLE )
public class PageHistoryConverter implements HistoryConverter<HyperlinkNavigationEventBus> {

	public String convertToToken( String eventName, String origin ) {
		return origin;
	}

	@Override
	public void convertFromToken( String name, String param, HyperlinkNavigationEventBus eventBus ) {
		eventBus.dispatch( name, param );
	}

	@Override
	public boolean isCrawlable() {
		return false;
	}

}
