package com.mvp4g.example.client.presenter;

import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.BasePresenter;
import com.mvp4g.example.client.HyperlinkNavigationEventBus;
import com.mvp4g.example.client.presenter.interfaces.IMenuView;
import com.mvp4g.example.client.presenter.interfaces.IMenuView.IMenuPresenter;
import com.mvp4g.example.client.view.MenuView;

@Presenter( view = MenuView.class )
public class MenuPresenter extends BasePresenter<IMenuView, HyperlinkNavigationEventBus> implements IMenuPresenter {
	
	@Override
	public void bind(){
		String tokenPage1 = getTokenGenerator().goToPage1( "You clicked the menu." );
		view.setPage1Token( tokenPage1 );
		
		String tokenPage2 = getTokenGenerator().goToPage2( "You clicked the menu." );
		view.setPage2Token( tokenPage2 );
	}

}
